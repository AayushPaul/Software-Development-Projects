/**
 * 
 */
/**
 * 
 */
module commandLineCalculator {
}